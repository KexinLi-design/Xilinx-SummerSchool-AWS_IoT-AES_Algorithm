/*
 * Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Additions Copyright 2016 Espressif Systems (Shanghai) PTE LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/**
 * @file aws_iot_certifcates.c
 * @brief File to store the AWS certificates in the form of arrays
 */

#ifdef __cplusplus
extern "C" {
#endif

const char aws_root_ca_pem[] = {"-----BEGIN CERTIFICATE-----\n\
MIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF\n\
ADA5MQswCQYDVQQGEwJVUzEPMA0GA1UEChMGQW1hem9uMRkwFwYDVQQDExBBbWF6\n\
b24gUm9vdCBDQSAxMB4XDTE1MDUyNjAwMDAwMFoXDTM4MDExNzAwMDAwMFowOTEL\n\
MAkGA1UEBhMCVVMxDzANBgNVBAoTBkFtYXpvbjEZMBcGA1UEAxMQQW1hem9uIFJv\n\
b3QgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4gHHKeNXj\n\
ca9HgFB0fW7Y14h29Jlo91ghYPl0hAEvrAIthtOgQ3pOsqTQNroBvo3bSMgHFzZM\n\
9O6II8c+6zf1tRn4SWiw3te5djgdYZ6k/oI2peVKVuRF4fn9tBb6dNqcmzU5L/qw\n\
IFAGbHrQgLKm+a/sRxmPUDgH3KKHOVj4utWp+UhnMJbulHheb4mjUcAwhmahRWa6\n\
VOujw5H5SNz/0egwLX0tdHA114gk957EWW67c4cX8jJGKLhD+rcdqsq08p8kDi1L\n\
93FcXmn/6pUCyziKrlA4b9v7LWIbxcceVOF34GfID5yHI9Y/QCB/IIDEgEw+OyQm\n\
jgSubJrIqg0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC\n\
AYYwHQYDVR0OBBYEFIQYzIU07LwMlJQuCFmcx7IQTgoIMA0GCSqGSIb3DQEBCwUA\n\
A4IBAQCY8jdaQZChGsV2USggNiMOruYou6r4lK5IpDB/G/wkjUu0yKGX9rbxenDI\n\
U5PMCCjjmCXPI6T53iHTfIUJrU6adTrCC2qJeHZERxhlbI1Bjjt/msv0tadQ1wUs\n\
N+gDS63pYaACbvXy8MWy7Vu33PqUXHeeE6V/Uq2V8viTO96LXFvKWlJbYK8U90vv\n\
o/ufQJVtMVT8QtPHRh8jrdkPSHCa2XV4cdFyQzR1bldZwgJcJmApzyMZFo6IQ6XU\n\
5MsI+yMRQ+hDKXJioaldXgjUkK642M4UwtBV8ob2xJNDd2ZhwLnoQdeXeGADbkpy\n\
rqXRfboQnoZsG4q5WTP468SQvvG5\n\
-----END CERTIFICATE-----\n"};

const char certificate_pem_crt[] = {"-----BEGIN CERTIFICATE-----\n\
MIIDWjCCAkKgAwIBAgIVANjYOo20981IoB3Z+Xp7ODWvKMVwMA0GCSqGSIb3DQEB\n\
CwUAME0xSzBJBgNVBAsMQkFtYXpvbiBXZWIgU2VydmljZXMgTz1BbWF6b24uY29t\n\
IEluYy4gTD1TZWF0dGxlIFNUPVdhc2hpbmd0b24gQz1VUzAeFw0yMDAzMTEwMjMz\n\
MTdaFw00OTEyMzEyMzU5NTlaMB4xHDAaBgNVBAMME0FXUyBJb1QgQ2VydGlmaWNh\n\
dGUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC9Pg4VXEp8q2Wf+FAk\n\
/dsDtqz4B75uWsjoa5tHYi0oNuUMA+W6A8I/cldy/YSwrRnzYnk+1X590GBOJLD5\n\
UIQBAqD2y0mx/K31mwtWQg4gtnASwtAL6IUXjVj8gOjO8sQrravgMYTcro/NJcS5\n\
9earwWhoOCByyYjCmEKshvSZbAMJ7hZN3HI06Dnn7Z7HoBa0qYY6GIaF1T+GvZfv\n\
l7UwH4t573G4LvoN+aeQYXKu4bvMKhtLQfNGekqa7/psXBp3PVHWigNYp/c0aroZ\n\
n17M+rw+qImUPUHKMzai7zQ4L7/OuO/MXdmhlNgZHSxZM+86sgyo6kn8ESZmVurM\n\
CeS3AgMBAAGjYDBeMB8GA1UdIwQYMBaAFNDoZxczEj5j4GTCmfe3yZ+6fv9YMB0G\n\
A1UdDgQWBBTTIegjtVC1adKralo1KVfVh5nuzTAMBgNVHRMBAf8EAjAAMA4GA1Ud\n\
DwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAQEAo3m7w/dWDGIiWHnNn8+EeXhm\n\
YSUhrG3WikjDcHE99TkBTNmqdsk5d9ojXOLuAN7nzFZ02BwyrJMsokGL44UPVxL/\n\
0oYx/Ry39dznwnauaIynNTJYocAug5z4p2W/KP3IObmd7FXKr4/6REUYfHeAw4k7\n\
2I7cH86ZCse95u0exdpZQ6aTV2tYVzYTFiKYl/pAyLsHk4eLRm6+1wSSxDgrFSCO\n\
dSQ3GQTdpIRes8CM+4IdsAbAp4GIWB2AfsAvemFEGzoWDeLhYMfzWj7yya1GpGL6\n\
4pTkYg9KWg3tbv5dWYA5Y7kQUGQnX7EAPZJCd87Z4H9YDeaHxhgmQ9auRAABYQ==\n\
-----END CERTIFICATE-----\n"};

const char private_pem_key[] = {"-----BEGIN RSA PRIVATE KEY-----\n\
MIIEowIBAAKCAQEAvT4OFVxKfKtln/hQJP3bA7as+Ae+blrI6GubR2ItKDblDAPl\n\
ugPCP3JXcv2EsK0Z82J5PtV+fdBgTiSw+VCEAQKg9stJsfyt9ZsLVkIOILZwEsLQ\n\
C+iFF41Y/IDozvLEK62r4DGE3K6PzSXEufXmq8FoaDggcsmIwphCrIb0mWwDCe4W\n\
TdxyNOg55+2ex6AWtKmGOhiGhdU/hr2X75e1MB+Lee9xuC76DfmnkGFyruG7zCob\n\
S0HzRnpKmu/6bFwadz1R1ooDWKf3NGq6GZ9ezPq8PqiJlD1ByjM2ou80OC+/zrjv\n\
zF3ZoZTYGR0sWTPvOrIMqOpJ/BEmZlbqzAnktwIDAQABAoIBAQC1X7Bn0JijfDJe\n\
a8OEcLlkicSlw+ZEJkbAW8HrXLEjBdno9iNLcSbPYGtoDosKOh3RIuRJ0Jz3QKvM\n\
uWXUzdJ2lWpontX2/NJNv1fSSGT5/WDU2lpDz4sf050iBPscvZg+tKkyqsNILxYr\n\
7LLr+D4pB6llmcWfvoCQ4RWl/YKZN0G4wBqTVKtGjQDlNMCMp3yd9BGxgWWVIkwD\n\
nJJVhtAXDVej4S7QLlPQleJHz5OrJcGbRF0N8t/XOnzgKE7ehXvAenMkWeW7FYJK\n\
KOmAZpOQRwPZJ0SIt0BYvy4ShX5r/bCt5GGfx8mr20nphcvuYaL0QKUcBUony8h1\n\
llPitZvBAoGBAOq/aStyjvfBY6vyzSs/xlqYY9tFj9wZhBhgkh3C35xaK0LKnpeI\n\
CUmQP58+i9+3jLXQGdt0h/beBVWb/TRhU1IXXiQfdhtkxBs763LKo7mYy7sAib+L\n\
VlZeSg+oEQRSivxz5x6kDrhYVX2JfjvMihyr7f/k7yjyJvliutCHkRAvAoGBAM5f\n\
/6VxQdgMOSg8irRgcmuBIjYGw43yzDumZ2GloYcRA0V33gWhBZsbRKyxKhbHKxs0\n\
2pBENxXAAjwtu2XH6j0X3tZ36sx2ZUe3TmeZQeS5OADd9Gls745AiArZ21znC5CO\n\
uQn821v17+uRylCi6Pkv6zgxaSFYE/Eti4h8OIn5AoGAcwliDHyTOy52Halaibsz\n\
BOpw5N9t5DpM1XVdpV/+HKzDTnPky/VKN9aMlwkbmoJkXiSgxz6P8pZSnuVWa/jV\n\
0ADLjYAtbLcwsvfmJdbP7P/HtthIqKkroh+Kw6lkzW111skllYpn/EatfluGlN9j\n\
PzGx7BjQaoxgNQ4A5nfIytkCgYAxAsNnuvn0IRMB5z7Zj34c4dIKGpkegObX07EB\n\
k6BEv1mTieAEXjVCnLs2d+yS9EHceDTfxhN+6tadDA9RIKUUVTLqpBfy7rsmyPWp\n\
zM/FTedq7Us6LlDF67VjPlHGQmiQsBRpts8xi7qqqzjs5YOGikbGVZWuAYja4gId\n\
K8MRoQKBgCDGF0kV1273hrtgOc+AQQ86Nej6kvDmMIDWrGhKJbGXcqhqm3hDj2YO\n\
9Spztn7WB/qhqmdQfe1kf7AwP3DR7I3xkyV1QoKY/6vKlDUkVt9bGqltPop4JNu2\n\
OzOcLhWxQ1SVumwgYTaNhitzEO1/n9Xyx/zuUghM1UO73Uo+IVtK\n\
-----END RSA PRIVATE KEY-----\n"};


#ifdef __cplusplus
}
#endif
