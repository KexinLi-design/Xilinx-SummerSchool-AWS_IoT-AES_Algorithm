AWS-loT案例中，ESP32开发使用到两个库WiFi库和AWS-loT库，其下载方式如下所示：
①WiFi库：Arduino-IDE官方库中的Arduino Uno Dev Ed Library库。
②AWS-loT库：https://github.com/ExploreEmbedded/Hornbill-Examples/tree/master/arduino-esp32/AWS_IOT
处下载，并在Arduino-IDE中添加库。